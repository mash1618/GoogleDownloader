import copy

from google_drive_downloader import GoogleDriveDownloader as Downloader
import platform
import logging
import os

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(message)s')
file_handler = logging.FileHandler('download.log', 'w')
file_handler.setFormatter(formatter)
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(formatter)

logger.addHandler(file_handler)
logger.addHandler(stream_handler)


def download_file(fileid, filename):
    file_name = filename
    file_old_name = copy.copy(filename)
    try:
        os_version = platform.system()
        logger.info(f'Found OS platform: {os_version}')
        if os_version == 'windows':
            logger.info(f'Found OS {os_version}')
            file_name = os.curdir+'\\'+filename
        elif os_version == 'linux':
            logger.info(f'Found OS {os_version}')
            file_name = os.curdir+'/'+filename
        Downloader.download_file_from_google_drive(file_id=fileid, dest_path=file_name)
        logger.info(f'{file_old_name} is download')
        return file_old_name
    except BaseException as exception_msg:
        logger.exception(f'Exception type: {type(exception_msg)}')
        logger.exception(f'Exception name: {exception_msg.__class__.__name__}')
        logger.exception(f'Exception description: {exception_msg}')
        exit()


if __name__ == '__main__':
    file_id = None
    file_name = None
    file_old_name = None
    while file_id is None:
        file_id = input('Enter the download file id: ')
    while file_name is None:
        file_name = input('Enter download file name with file extension : ')
    logger.info(f'User provided file id : {file_id}')
    logger.info(f'User provided output file name with file extension: {file_name}')
    download_file(file_id, file_name)




