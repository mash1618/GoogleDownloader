import logging

import GoogleDriveFileDownloader
import os
"""
This is one example for test cases
"""

def test_download_file():
    logging.info('Verifying the user able to download ')
    result = GoogleDriveFileDownloader.download_file('1D6SAfo1l8Uf_ND661vifzsLUyH1dRIN7', 'abc.png')
    assert result == 'abc.png'

