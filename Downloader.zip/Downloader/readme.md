This document explains how to execute the downloader [GoogleDriveFileDownloader.py] script on Windows and Linux.
Python 3.7.6 is used to write the program and below modules are used.
> googledrivedownloader [pip install googledrivedownloader]
> platform [built-in]
> logging [built-in]
> os [built-in]
> copy [built-in]


Steps to run the Script:
1. unzip the 'Downloader.zip' 
2. Execute the script on windows using command : 
> python GoogleDriveFileDownloader.py
3. Execute the script on Linux using command :
> python GoogleDriveFileDownloader.py if only python3 only installed
or
> python3 GoogleDriveFileDownloader.py if both python2 and 3 are present in the machine

4. Enter Following inputs.
> Enter the download file id: [ id of the shared file]
> Enter download file name with file extension: [ user can input any name but extension should match with original]








